# ------------------------------------------------------------------------
# Grounding DINO
# url: https://github.com/IDEA-Research/GroundingDINO
# Copyright (c) 2023 IDEA. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
# Conditional DETR
# Copyright (c) 2021 Microsoft. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
# Copied from DETR (https://github.com/facebookresearch/detr)
# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
# ------------------------------------------------------------------------

# import 操作触发对象注册
from .groundingdino import build_groundingdino
from .groundingdino_tiny import build_groundingdino_tiny
from .groundingdino_tiny_A import build_groundingdino_tiny_A
from .groundingdino_tiny_AB import build_groundingdino_tiny_AB
from .groundingdino_tiny_AB1 import build_groundingdino_tiny_AB1
from .groundingdino_tiny_AC import build_groundingdino_tiny_AC
from .groundingdino_tiny_AC1 import build_groundingdino_tiny_AC1
from .groundingdino_tiny_AD import build_groundingdino_tiny_AD
from .groundingdino_tiny_AD0 import build_groundingdino_tiny_AD0
from .groundingdino_tiny_AD1 import build_groundingdino_tiny_AD1
from .groundingdino_tiny_AD2 import build_groundingdino_tiny_AD2
from .groundingdino_tiny_AD21 import build_groundingdino_tiny_AD21
from .groundingdino_tiny_AD22 import build_groundingdino_tiny_AD22
from .groundingdino_tiny_AD23 import build_groundingdino_tiny_AD23
from .groundingdino_tiny_AD24 import build_groundingdino_tiny_AD24
from .groundingdino_tiny_AD25 import build_groundingdino_tiny_AD25
from .groundingdino_tiny_AE0 import build_groundingdino_tiny_AE0
from .groundingdino_base import build_groundingdino_base
from .groundingdino_base_ptuning import build_groundingdino_base_ptuning
from .groundingdino_large import build_groundingdino_large
from .groundingdino_large_A import build_groundingdino_large_A
from .groundingdino_huge import build_groundingdino_huge

from .groundingdino_swinV2_tiny import groundingdino_swinV2_tiny
